namespace Nhaama.Memory
{
    /// <summary>
    /// Type of string encoding to write
    /// </summary>
    public enum StringEncodingType
    {
        ASCII,
        Unicode,
        Utf8
    }
}